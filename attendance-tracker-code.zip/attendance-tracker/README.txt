ATTENDANCE TRACKER

1. Extract the ZIP.
2. Open the attendance-tracker folder in VS Code.
3. Open index.html with the Live Server extension (recommended), or in a modern browser.

index.html: page structure
style.css: design and responsive layout
script.js: attendance calculations, leave planner and saved records

No npm installation required. Google Fonts requires internet; system fonts are used otherwise. Attendance is saved in the current browser, and does not sync between devices.

Safe missed classes = floor((100 * attended - target * total) / target), when already at the target.
Recovery classes = ceil((target * total - 100 * attended) / (100 - target)). A 100% target cannot be recovered exactly after an absence.
